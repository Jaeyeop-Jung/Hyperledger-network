
package org.hyperledger.fabric.samples.assettransfer;

import java.util.HashMap;
import java.util.Objects;

import lombok.*;
import org.hyperledger.fabric.contract.annotation.DataType;
import org.hyperledger.fabric.contract.annotation.Property;

@DataType()
@Getter
@ToString
@AllArgsConstructor
public final class Asset {

    @Property()
    private final String assetID;

    @Property()
    private final String owner;

    @Property()
    private final HashMap<String, String> coin;

    @Property()
    private final String sender;

    @Property()
    private final String receiver;

    @Property()
    private final String amount;

    public static Asset of(final String assetID, final String owner, final HashMap<String, String> coin, final String sender, final String receiver, final String amount) {
        return new Asset(assetID, owner, coin, sender, receiver, amount);
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Asset asset = (Asset) o;
        return Objects.equals(getAssetID(), asset.getAssetID()) && Objects.equals(getOwner(), asset.getOwner()) && Objects.equals(getCoin(), asset.getCoin()) && Objects.equals(this.getSender(), asset.getSender()) && Objects.equals(this.getReceiver(), asset.getReceiver()) && Objects.equals(getAmount(), asset.getAmount());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAssetID(), getOwner(), getCoin(), this.getSender(), this.getReceiver(), getAmount());
    }
}
